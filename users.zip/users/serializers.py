from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken,TokenError
from . models import *

class SignUpFirstPageSerializer(serializers.Serializer):
    
        email = serializers.EmailField()
 
class CustomAuthTokenSerializer(serializers.Serializer):
        email = serializers.EmailField()
        password = serializers.CharField(max_length=255)
         
                

class SignUpRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model=User        
        fields = ['email','password1','OTP','password2']
        
        
        
        
class LoginSerializer(serializers.Serializer):
        email = serializers.EmailField()
        password = serializers.CharField(max_length=255)
        
        

class ResetPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password1 = serializers.CharField(max_length=255)
    password2 = serializers.CharField(max_length=255)
    OTP = serializers.CharField(max_length=255)
    
    
class LogoutSerializer(serializers.Serializer):
        refresh = models.CharField(max_length=255)
        
        default_error_message = {
                'bad_token':{'Token is invalid or expired'}
        }
        
        def validate(self,attrs):
                self.token = attrs['refresh']
                return attrs
        
        def save(self,**kwargs):
                try:
                        RefreshToken(self.token).blacklist
                except TokenError:
                        self.fail('bad_token')