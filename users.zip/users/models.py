
from django.db import models
#from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractBaseUser,PermissionsMixin,BaseUserManager



# Create your models here.


from django.db import models



class UserManager(BaseUserManager):

    def create_user(self, email, password=None):
        if email is None:
            raise TypeError('Users should have a Email')

        user = self.model(email=self.normalize_email(email))
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password=None):
        if password is None:
            raise TypeError('Password should not be none')

        user = self.create_user( email, password)
        user.is_superuser = True
        user.is_staff = True
        user.save()
        return user



class User(AbstractBaseUser, PermissionsMixin):
    #username = models.CharField(max_length=255, unique=True, db_index=True)
    email = models.EmailField(max_length=255, unique=True, db_index=True)
    password1 = models.CharField(max_length=255,null=True)
    password2 = models.CharField(max_length=255,null=True)
    password = models.CharField(max_length=255)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    OTP = models.CharField(max_length=255,null=True)
    RM_User = models.BooleanField(default=False)
    RM_Code = models.CharField(max_length=255,null=True)
    is_admin = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default = False)
    

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = UserManager()

    def __str__(self):
        return self.email







# class User(models.Model):
#     class Meta:
#         db_table = 'USER_TABLE'
    
#     email = models.EmailField(primary_key=True)
#     password1 = models.CharField(max_length=255,null=True)
#     OTP = models.CharField(max_length=255,null=True)
#     password2 = models.CharField(max_length=255,null=True)
#     RM_user = models.BooleanField(default=False)
    
#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = []
    
    
class OTP_Verification(models.Model):
    class Meta:
        db_table = 'VERIFICATION_TABLE'
    email = models.EmailField(primary_key=True)
    OTP = models.CharField(max_length=255,null=True)
    

class Admin_User(models.Model):
    class Meta:
        db_table = 'LT_ADMIN_USER'
    
    FROM_DATE= models.DateField()
    TO_DATE = models.DateField()
    ADMIN_NAME = models.CharField(max_length=255)
    EMAIL = models.EmailField(primary_key=True)
    MOBILE_NO = models.CharField(max_length=10)
    DESIGNATION = models.CharField(max_length=255)
    
    
# class Admin_User_Configuration(models.Model):
#     class Meta:
#         db_table='ADMIN_USER_CONFIGURATION'
        
#     RM_CODE = models.CharField(max_length=255,null=True)
#     NAME = models.CharField(max_length=255,null=True)
#     EMAIL = models.EmailField(primary_key=True)
#     MOBILE= models.CharField(max_length=10,null=True)
#     PINCODE=models.IntegerField(max_length=6,null=True)
#     DESIGNATION=models.CharField(max_length=255,null=True)
#     REPORTS_TO=models.CharField(max_length=255,null=True)
#     PASSWORD=models.CharField(max_length=255,null=True)
    
